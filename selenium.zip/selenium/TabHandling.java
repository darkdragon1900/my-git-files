package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class TabHandling {

	public static void main(String[] args) {
		//tabhandling
		WebDriver driver = new ChromeDriver();
		//String parent = driver.getWindowHandle();
		
		driver.get("https://codenboxautomationlab.com/registration-form/");
		
		driver.switchTo().newWindow(WindowType.TAB);
		String parent2 = driver.getWindowHandle();
		driver.get("https://mail.google.com/mail/u/0/?ogbl#inbox");
		
		//driver.switchTo().window(parent);
		
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get("https://demo.guru99.com/test/radio.html");
		
		//driver.switchTo().window(parent);
		
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get("https://github.com/darkdragon1900?tab=repositories");
		
		driver.switchTo().window(parent2);
		driver.close();
		
	
		
	}

}
