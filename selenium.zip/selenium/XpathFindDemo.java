package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathFindDemo {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver dr = new ChromeDriver();
		//dr.get("https://demo.guru99.com/");
		dr.get("https://demo.guru99.com/V1/index.php");
		dr.manage().window().maximize();
		//finding by name
		Thread.sleep(1000);
		//dr.findElement(By.name("emailid")).sendKeys("shivamgosavi19@gmail.com");
		
		//dr.findElement(By.xpath("//a[contains(text(),'here')]")).click();
		//dr.findElement(By.linkText("here")).click();
		//dr.findElement(By.partialLinkText("he")).click();
//		dr.findElement(By.name("uid")).click();
//		dr.findElement(By.name("password")).click();
//		
		//how to print error message
//		WebElement we = dr.findElement(By.name("uid"));
//		we.click();
//		WebElement we1 = dr.findElement(By.name("password"));
//		we1.click();
//		WebElement s = dr.findElement(By.id("message23"));
//		System.out.println("User id Error Message is :"+s.getText());
//		we.click();
//		WebElement s1 = dr.findElement(By.id("message18"));
//		System.out.println("Password Error Message is :"+s1.getText());
		
		WebElement userId = dr.findElement(By.name("uid"));
		WebElement passWord = dr.findElement(By.name("password"));
		userId.click();
		Thread.sleep(2000);
		userId.sendKeys("Shivam");
		passWord.sendKeys("1234");
		Thread.sleep(2000);
		userId.clear();
		Thread.sleep(2000);
		userId.sendKeys("Manish");
		passWord.sendKeys("4567");
		Thread.sleep(2000);
		dr.close();


	}

}
