package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NewWebsiteSauceDemo {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/v1/");
		dr.manage().window().maximize();
		Thread.sleep(1000);
		dr.findElement(By.name("user-name")).sendKeys("standard_user");
		Thread.sleep(1000);
		dr.findElement(By.id("password")).sendKeys("secret_sauce");
		Thread.sleep(1000);
		dr.findElement(By.id("login-button")).click();
		Thread.sleep(1000);
//		dr.findElement(By.className("btn_primary btn_inventory")).click();
//		Thread.sleep(1000);
//		dr.findElement(By.xpath("//body[1]/div[1]/div[2]/div[1]/div[2]/a[1]/svg[1]/path[1]")).click();
//		Thread.sleep(1000);
//		dr.findElement(By.className("btn_action checkout_button")).click();
//		Thread.sleep(1000);
		dr.findElement(By.xpath("//button[contains(text(),'Open Menu')]")).click();
		Thread.sleep(1000);
		dr.findElement(By.id("logout_sidebar_link")).click();
		Thread.sleep(1000);
		dr.close();

	}

}
