package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class DragDrop {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver dr = new ChromeDriver();
		dr.get("https://demo.guru99.com/test/drag_drop.html");
		dr.manage().window().maximize();
		
		Actions action = new Actions(dr);
		
		WebElement drag = dr.findElement(By.xpath("//*[@id=\"fourth\"]/a"));
		WebElement drop = dr.findElement(By.xpath("//*[@id=\"amt7\"]/li"));
		Thread.sleep(1000);
		action.dragAndDrop(drag, drop).build().perform();
		Thread.sleep(1000);
		
		WebElement drag1 = dr.findElement(By.xpath("//*[@id=\"credit2\"]/a"));
		WebElement drop1 = dr.findElement(By.xpath("//*[@id=\"bank\"]/li"));
		Thread.sleep(1000);
		action.dragAndDrop(drag1, drop1).build().perform();
		
		
		
		
		

	}

}
