package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SauceDemoWebsite {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		dr.manage().window().maximize();
		Thread.sleep(1000);
		dr.findElement(By.name("user-name")).sendKeys("standard_user");
		Thread.sleep(1000);
		dr.findElement(By.id("password")).sendKeys("secret_sauce");
		Thread.sleep(1000);
		dr.findElement(By.id("login-button")).click();
		Thread.sleep(1000);
		dr.findElement(By.xpath("//button[contains(text(),'Open Menu')]")).click();
		Thread.sleep(1000);
		dr.findElement(By.id("logout_sidebar_link")).click();
		Thread.sleep(1000);
		
		WebElement we = dr.findElement(By.name("user-name"));
		we.sendKeys("Shivam");
		dr.findElement(By.id("login-button")).click();
		Thread.sleep(1000);
		
		WebElement s1 = dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3"));
		System.out.println("Error Message : "+s1.getText());
		
		
		
		dr.close();
	}

}
