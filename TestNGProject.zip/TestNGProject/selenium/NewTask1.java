package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class NewTask1 {

	public static void main(String[] args) {

		WebDriver dr = new ChromeDriver();
		String parent = dr.getWindowHandle();
		dr.get("https://demo.guru99.com/v4/");
		dr.manage().window().maximize();
		System.out.println("Website Title is : "+dr.getTitle());
		dr.switchTo().newWindow(WindowType.TAB);
		String parent2 = dr.getWindowHandle();
		dr.get("https://demo.automationtesting.in/Register.html");
		dr.manage().window().maximize();
		dr.switchTo().window(parent);
		dr.switchTo().window(parent2);
		System.out.println("\nCurrent url is "+dr.getCurrentUrl());
		
		WebElement name = dr.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[1]/input"));
		name.sendKeys("Shivam");
		WebElement lastname = dr.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[2]/input"));
		lastname.sendKeys("Gosavi");
		
		dr.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[2]/div/textarea")).sendKeys("Peth Road , Nashik");
		dr.findElement(By.xpath("//*[@id=\"eid\"]/input")).sendKeys("shivamgosavi19@gmail.com");
		
		WebElement mobile = dr.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[4]/div/input"));
		mobile.sendKeys("9960493185");
		
		dr.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[5]/div/label[1]/input")).click();
		dr.findElement(By.xpath("//*[@id=\"checkbox1\"]")).click();
		
		WebElement dob1 = dr.findElement(By.xpath("//*[@id=\"yearbox\"]"));
		Select sl = new Select(dob1);
		sl.selectByValue("2001");
		
		WebElement dob2 = dr.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[11]/div[2]/select"));
		Select s2 = new Select(dob2);
		s2.selectByValue("October");
		
		WebElement dob3 = dr.findElement(By.xpath("//*[@id=\"daybox\"]"));
		Select s3 = new Select(dob3);
		s3.selectByValue("11");
		
		WebElement pass = dr.findElement(By.xpath("//*[@id=\"firstpassword\"]"));
		pass.sendKeys("Shivam123");
		System.out.println("\n Password : "+pass.getAttribute("value"));
		
		
		
		WebElement pass2 = dr.findElement(By.xpath("//*[@id=\"secondpassword\"]"));
		pass2.sendKeys("Shivam123");
		System.out.println("\n Password2 : "+pass2.getAttribute("value"));
		
		dr.findElement(By.xpath("//*[@id=\"submitbtn\"]")).click();
		
		
		
		
		
		
	}

}
