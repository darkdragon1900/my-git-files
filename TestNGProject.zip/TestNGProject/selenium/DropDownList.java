package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class DropDownList {

	public static void main(String[] args) throws InterruptedException {


		WebDriver driver = new ChromeDriver();
		driver.get("https://codenboxautomationlab.com/registration-form/");
		driver.manage().window().maximize();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"nf-field-17\"]")).sendKeys("Shivam");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"nf-field-18\"]")).sendKeys("Gosavi");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"nf-field-19\"]")).sendKeys("shivamgosavi19@gmail.com");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"nf-field-20\"]")).sendKeys("9960493185");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"nf-label-class-field-23-5\"]")).click();
		Thread.sleep(1000);
		
		WebElement we = driver.findElement(By.xpath("//*[@id=\"nf-field-22\"]"));
		Select sl = new Select(we);
		sl.selectByIndex(2);
		
		WebElement we1 = driver.findElement(By.xpath("//*[@id=\"nf-field-24\"]"));
		Select s2 = new Select(we1);
		s2.selectByVisibleText("October");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"nf-field-15\"]")).click();
		Thread.sleep(2000);
		//driver.close();
		
		System.out.println("Web Form Submitted!!!");
		
		
		
		
		
		
	}

}
