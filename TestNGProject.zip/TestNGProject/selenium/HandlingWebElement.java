package selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWebElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver dr = new ChromeDriver();
		dr.get("https://demo.guru99.com/v4/");
		dr.manage().window().maximize();
		dr.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr567691");	
		dr.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]")).sendKeys("AjAsyqY");
		dr.findElement(By.xpath("//input[@name='btnLogin']")).click();

		dr.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr");	
		dr.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]")).sendKeys("AjA");
		dr.findElement(By.xpath("//input[@name='btnLogin']")).click();
		
		Alert a1 = dr.switchTo().alert();
		System.out.println("Message :"+a1.getText());
		a1.accept();
		
		
	}

}
