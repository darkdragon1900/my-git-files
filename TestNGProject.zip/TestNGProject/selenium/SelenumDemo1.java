package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SelenumDemo1 {

	public static void main(String[] args) throws InterruptedException {
		//Import Selenium jar
		//Selenium version 4.19.1
		
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.google.com");

//		
		String url = "https://www.google.com";
//		dr.get(url);
		
		//dr.navigate().to(url);
		dr.manage().window().maximize();//to maximize
		dr.get("https://www.gmail.com");
		Thread.sleep(3000);
		dr.manage().window().minimize();
		dr.manage().window().maximize();
		System.out.println("Website Title is : "+ dr.getTitle());
		String myTitle= "Welcome";
		System.out.println("\nMy Title is : "+myTitle);
		
		if(myTitle.equals(dr.getTitle()))
			System.out.println("\nTitle Match Passed");
		else
			System.out.println("\nTitle Match Failed");
		
		System.out.println("\nCurrent Url is "+dr.getCurrentUrl());
		
		//System.out.println("\nCurrent Url is "+dr.getPageSource());
		dr.navigate().back();
		Thread.sleep(3000);
		dr.navigate().forward();
		Thread.sleep(2000);
		
		
		
		

	}

}
