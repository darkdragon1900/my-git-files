package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClassTask {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver dr = new ChromeDriver();
//		dr.get("https://www.saucedemo.com/");
//		Thread.sleep(1000);
//		WebElement we = dr.findElement(By.name("user-name"));
//		we.sendKeys("Shivam");
//		we.sendKeys("gosavi");
//		String str = we.getAttribute("value");
//		System.out.println(str);
		
		dr.get("https://demo.guru99.com/");
		Thread.sleep(1000);
		dr.findElement(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li[1]/a")).click();
		Thread.sleep(1000);
		dr.findElement(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li[1]/ul/li[2]/a")).click();
		Thread.sleep(1000);
		
		//dr.findElement(By.xpath("//*[@id=\"vfb-7-1\"]")).click();
		
		dr.get("https://demoqa.com/radio-button");
		dr.findElement(By.xpath("//*[@id=\"app\"]/div/div/div/div[2]/div[2]/div[2]/label")).click();
		dr.findElement(By.xpath("/html/body/iframe[1]")).click();
		
		
		
		
		
		
		
		
		
		

	}

}
