package com.testng;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Login {
	WebDriver dr = new ChromeDriver();
  @Test(priority=1)
  public void openWebPage() throws InterruptedException {
	  

		
		dr.get("https://demo.guru99.com/v4/");
		dr.manage().window().maximize();
		dr.findElement(By.xpath("//input[@name='uid']")).sendKeys("mngr567691");	
		dr.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]")).sendKeys("AjAsyqY");
		dr.findElement(By.xpath("//input[@name='btnLogin']")).click();
  }
  

@Test(priority=2)
public void newCustomer()
{

	dr.findElement(By.xpath("/html/body/div[3]/div/ul/li[2]/a")).click();
	dr.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[4]/td[2]/input")).sendKeys("Shivam");
	dr.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[7]/td[2]/textarea")).sendKeys("Peth road,Nashik");
}

}