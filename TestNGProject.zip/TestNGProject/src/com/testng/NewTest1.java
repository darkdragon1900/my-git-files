package com.testng;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void f() {
  }
}
