package com.testng;

import org.testng.SkipException;
import org.testng.annotations.Test;

public class Priority {
  @Test(priority=3)
  public void home() {
	  System.out.println("Home page");
  }
  @Test(priority=2)
  public void register() {
	  throw new SkipException("Test Skipped");
	  //System.out.println("Register");
  }
  @Test(priority=1 )
  public void login() {
	  System.out.println("login page");
  }
}
